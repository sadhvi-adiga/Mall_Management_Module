package com.demo.entities;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;

public class mall {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
@Entity
public class Shop {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private string mallName;
    private string location;
    private long shopsid;
    // Add more fields and getter/setter methods
}